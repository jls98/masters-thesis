from . import factorgpg

if __name__ == "__main__":
    exit(factorgpg() or 0)

