# factorgpg

A python module to extract prime factors from old gnupg square-and-multiply traces.
